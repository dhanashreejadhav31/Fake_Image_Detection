from PIL import Image
from PIL.ExifTags import TAGS
import numpy as np
import cv2

def analyze_metadata(image_path):
    """Analyze image metadata for potential manipulation indicators"""
    try:
        # Open image and extract EXIF data
        image = Image.open(image_path)
        exif = image._getexif()
        
        if not exif:
            return {
                'has_metadata': False,
                'warning': 'No EXIF metadata found - could indicate manipulation'
            }
            
        # Process EXIF data
        exif_data = {}
        for tag_id in exif:
            tag = TAGS.get(tag_id, tag_id)
            data = exif.get(tag_id)
            if isinstance(data, bytes):
                data = data.decode(errors='ignore')
            exif_data[tag] = str(data)
            
        # Check for software manipulation
        software_indicators = ['photoshop', 'gimp', 'lightroom', 'ai']
        software_used = None
        if 'Software' in exif_data:
            software = exif_data['Software'].lower()
            for indicator in software_indicators:
                if indicator in software:
                    software_used = exif_data['Software']
                    break
                    
        return {
            'has_metadata': True,
            'software_detected': software_used,
            'creation_tool': exif_data.get('Software', 'Unknown'),
            'original_datetime': exif_data.get('DateTimeOriginal', 'Unknown'),
            'last_modified': exif_data.get('DateTime', 'Unknown'),
            'device_make': exif_data.get('Make', 'Unknown'),
            'device_model': exif_data.get('Model', 'Unknown')
        }
        
    except Exception as e:
        return {
            'error': f"Error analyzing metadata: {str(e)}",
            'has_metadata': False
        }

def analyze_noise_patterns(image_path):
    """Analyze image noise patterns for potential manipulation"""
    try:
        # Read image
        img = cv2.imread(image_path)
        
        # Convert to grayscale
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        
        # Apply noise analysis filter
        noise = cv2.fastNlMeansDenoising(gray)
        diff = cv2.absdiff(gray, noise)
        
        # Calculate noise statistics
        noise_mean = np.mean(diff)
        noise_std = np.std(diff)
        noise_max = np.max(diff)
        
        # Check for inconsistent noise patterns
        blocks = []
        height, width = diff.shape
        block_size = 32
        
        for y in range(0, height - block_size, block_size):
            for x in range(0, width - block_size, block_size):
                block = diff[y:y+block_size, x:x+block_size]
                blocks.append(np.std(block))
                
        block_std = np.std(blocks)
        
        return {
            'noise_level': float(noise_mean),
            'noise_std': float(noise_std),
            'noise_max': float(noise_max),
            'noise_consistency': float(block_std),
            'suspicious': block_std > 10.0  # Threshold for suspicious noise patterns
        }
        
    except Exception as e:
        return {
            'error': f"Error analyzing noise patterns: {str(e)}"
        }
