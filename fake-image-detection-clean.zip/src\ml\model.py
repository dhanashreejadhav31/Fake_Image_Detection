import numpy as np
import cv2
from PIL import Image
from skimage.feature import local_binary_pattern
from skimage import img_as_ubyte
from scipy.stats import entropy

class ImageDetector:
    def __init__(self):
        self.target_size = (224, 224)
        self.n_points = 24
        self.radius = 3
        
    def preprocess_image(self, image_path):
        """Preprocess image for analysis"""
        # Load and resize image
        img = cv2.imread(image_path)
        img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        img = cv2.resize(img, self.target_size)
        return img
        
    def extract_features(self, image):
        """Extract texture and noise features"""
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        
        # Calculate LBP
        lbp = local_binary_pattern(gray, self.n_points, self.radius, method='uniform')
        
        # Calculate noise pattern
        denoised = cv2.fastNlMeansDenoising(gray)
        noise = cv2.absdiff(gray, denoised)
        
        # Extract features
        features = {
            'lbp_entropy': entropy(np.histogram(lbp, bins=2**8)[0]),
            'noise_mean': np.mean(noise),
            'noise_std': np.std(noise),
            'noise_entropy': entropy(np.histogram(noise, bins=2**8)[0])
        }
        
        return features
        
    def analyze_artifacts(self, features):
        """Analyze features for manipulation artifacts"""
        # Adjusted thresholds for better sensitivity
        noise_std_threshold = 0.3  # Lower threshold for noise standard deviation
        noise_entropy_threshold = 0.4  # Lower threshold for noise entropy
        lbp_entropy_threshold = 2.5  # Adjusted threshold for texture consistency
        
        # Calculate individual scores (0 to 1 range)
        noise_variation_score = min(features['noise_std'] / noise_std_threshold, 1.0)
        noise_pattern_score = min(features['noise_entropy'] / noise_entropy_threshold, 1.0)
        texture_score = min(abs(features['lbp_entropy'] - lbp_entropy_threshold) / lbp_entropy_threshold, 1.0)
        
        # Weighted combination of scores
        total_score = (
            noise_variation_score * 0.4 +
            noise_pattern_score * 0.3 +
            texture_score * 0.3
        )
        
        # Determine if fake based on total score
        is_fake = total_score > 0.4  # Lower threshold for more sensitivity
        confidence = min(total_score * 1.25, 1.0)  # Scale confidence, max at 100%
        
        return is_fake, confidence
        
    def analyze(self, image_path):
        """Main analysis function"""
        try:
            # Preprocess image
            preprocessed = self.preprocess_image(image_path)
            
            # Extract features
            features = self.extract_features(preprocessed)
            
            # Analyze for manipulation artifacts
            is_fake, confidence = self.analyze_artifacts(features)
            
            # Prepare detailed analysis
            details = {
                'feature_statistics': {
                    'noise_level': float(features['noise_mean']),
                    'noise_variation': float(features['noise_std']),
                    'texture_consistency': float(features['lbp_entropy']),
                    'noise_pattern': float(features['noise_entropy'])
                },
                'analysis_version': '1.0',
                'model_type': 'LBP-Noise-Analysis'
            }
            
            return {
                'is_fake': bool(is_fake),
                'confidence': float(confidence),
                'details': details
            }
            
        except Exception as e:
            raise Exception(f"Error analyzing image: {str(e)}")
