document.addEventListener('DOMContentLoaded', function() {
    const uploadForm = document.getElementById('uploadForm');
    const progressBar = document.getElementById('uploadProgress');
    const resultDiv = document.getElementById('result');
    
    if (uploadForm) {
        uploadForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            const fileInput = this.querySelector('input[type="file"]');
            
            if (!fileInput.files.length) {
                showError('Please select an image to analyze');
                return;
            }
            
            // Show progress bar
            progressBar.classList.remove('d-none');
            progressBar.querySelector('.progress-bar').style.width = '0%';
            
            // Hide previous results
            resultDiv.classList.add('d-none');
            
            // Simulate progress
            let progress = 0;
            const progressInterval = setInterval(() => {
                progress += 5;
                if (progress <= 90) {
                    progressBar.querySelector('.progress-bar').style.width = progress + '%';
                }
            }, 100);
            
            // Send request
            fetch('/upload', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                clearInterval(progressInterval);
                progressBar.querySelector('.progress-bar').style.width = '100%';
                
                setTimeout(() => {
                    progressBar.classList.add('d-none');
                    showResult(data);
                }, 500);
            })
            .catch(error => {
                clearInterval(progressInterval);
                progressBar.classList.add('d-none');
                showError('Error analyzing image: ' + error.message);
            });
        });
    }
    
    function showResult(data) {
        if (data.error) {
            showError(data.error);
            return;
        }
        
        const resultAlert = resultDiv.querySelector('.alert');
        const resultTitle = resultDiv.querySelector('.result-title');
        const resultMessage = resultDiv.querySelector('.result-message');
        const resultDetails = resultDiv.querySelector('.result-details');
        
        // Update result styling
        resultAlert.className = 'alert ' + (data.results.is_fake ? 'alert-danger' : 'alert-success');
        
        // Update content
        resultTitle.textContent = data.results.is_fake ? 'Potential Manipulation Detected' : 'No Manipulation Detected';
        resultMessage.textContent = `Confidence: ${(data.results.confidence * 100).toFixed(1)}%`;
        
        // Format details
        let detailsHtml = '<h5 class="mt-3">Analysis Details</h5>';
        detailsHtml += '<ul class="list-unstyled">';
        
        // Add ML analysis details
        const mlDetails = data.results.details;
        detailsHtml += '<li><strong>Feature Analysis:</strong></li>';
        detailsHtml += '<li>Feature Statistics:</li>';
        detailsHtml += `<li>- Noise Level: ${mlDetails.feature_statistics.noise_level.toFixed(3)}</li>`;
        detailsHtml += `<li>- Noise Variation: ${mlDetails.feature_statistics.noise_variation.toFixed(3)}</li>`;
        detailsHtml += `<li>- Texture Consistency: ${mlDetails.feature_statistics.texture_consistency.toFixed(3)}</li>`;
        detailsHtml += `<li>- Noise Pattern: ${mlDetails.feature_statistics.noise_pattern.toFixed(3)}</li>`;
        detailsHtml += `<li>Model Type: ${mlDetails.model_type}</li>`;
        detailsHtml += `<li>Analysis Version: ${mlDetails.analysis_version}</li>`;
        
        detailsHtml += '</ul>';
        resultDetails.innerHTML = detailsHtml;
        
        // Show result
        resultDiv.classList.remove('d-none');
    }
    
    function showError(message) {
        const resultAlert = resultDiv.querySelector('.alert');
        resultAlert.className = 'alert alert-danger';
        resultDiv.querySelector('.result-title').textContent = 'Error';
        resultDiv.querySelector('.result-message').textContent = message;
        resultDiv.querySelector('.result-details').innerHTML = '';
        resultDiv.classList.remove('d-none');
    }
});
