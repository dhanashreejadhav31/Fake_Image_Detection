# Fake Image Detector

A modern web application that uses deep learning to detect manipulated or AI-generated images. Built with Flask and TensorFlow.

## Features

- Upload and analyze images for potential manipulation
- Deep learning-based detection of AI-generated images
- User authentication and history tracking
- Detailed analysis results with confidence scores
- Modern, responsive UI

## Setup

1. Create a virtual environment:
```bash
python -m venv venv
source venv/bin/activate  # On Windows: .\venv\Scripts\activate
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Initialize the database:
```bash
python create_db.py
```

4. Run the application:
```bash
python app.py
```

The application will be available at http://localhost:5000

## Project Structure

```
fake-image-detector/
├── app.py                  # Main Flask application
├── create_db.py           # Database initialization script
├── requirements.txt       # Project dependencies
├── static/               # Static files (CSS, JS, images)
├── templates/            # HTML templates
└── src/                 # Source code
    ├── ml/             # Machine learning models
    └── utils/          # Utility functions
```
